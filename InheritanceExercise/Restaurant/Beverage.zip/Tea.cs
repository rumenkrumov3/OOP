﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Tea : HotBeverage
    {
        public Tea(decimal price, double milliliters) : base(price, milliliters)
        {

        }
    }
}
